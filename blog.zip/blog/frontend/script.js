const apiBase = "http://localhost:5000/api";

async function fetchPosts() {
  const res = await fetch(`${apiBase}/posts`);
  const posts = await res.json();
  displayPosts(posts);
}

function displayPosts(posts) {
  const container = document.getElementById("posts");
  container.innerHTML = "";

  posts.forEach((post) => {
    const div = document.createElement("div");
    div.classList.add("post");

    const commentCount = post.comments.length;
    div.innerHTML = `
      <h3>${post.title}</h3>
      <p>${post.content}</p>
      <div class="controls">
        <button onclick="startEdit('${post.id}', '${post.title}', '${post.content}')">✏️ Edit</button>
        <button onclick="deletePost('${post.id}')">🗑 Delete</button>
        <span class="comment-badge">💬 ${commentCount}</span>
      </div>

      <h4>Comments:</h4>
      <div>${post.comments.map(c => `<p class="comment">💭 ${c.text}</p>`).join("")}</div>
      <input placeholder="Add comment..." id="comment-${post.id}">
      <button onclick="addComment('${post.id}')">Add Comment</button>
    `;

    container.appendChild(div);
  });
}

// ✅ Add new post
document.getElementById("addPostBtn").addEventListener("click", async () => {
  const title = document.getElementById("title").value;
  const content = document.getElementById("content").value;
  if (!title || !content) return alert("Please fill all fields");

  await fetch(`${apiBase}/posts`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, content }),
  });
  document.getElementById("title").value = "";
  document.getElementById("content").value = "";
  fetchPosts();
});

// ✅ Delete post
async function deletePost(id) {
  await fetch(`${apiBase}/posts/${id}`, { method: "DELETE" });
  fetchPosts();
}

// ✅ Add comment
async function addComment(postId) {
  const input = document.getElementById(`comment-${postId}`);
  const text = input.value;
  if (!text) return;
  await fetch(`${apiBase}/posts/${postId}/comments`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text }),
  });
  input.value = "";
  fetchPosts();
}

// ✏️ Edit post
function startEdit(id, title, content) {
  const newTitle = prompt("Edit title:", title);
  const newContent = prompt("Edit content:", content);
  if (newTitle && newContent) updatePost(id, newTitle, newContent);
}

async function updatePost(id, title, content) {
  await fetch(`${apiBase}/posts/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, content }),
  });
  fetchPosts();
}

fetchPosts();
