const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const fs = require("fs");
const { v4: uuid } = require("uuid");
const path = require("path");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// ✅ Save data.json directly in backend folder
const dataFile = path.join(__dirname, "data.json");

// ✅ Ensure file exists when the server starts
if (!fs.existsSync(dataFile)) {
  fs.writeFileSync(dataFile, JSON.stringify([], null, 2));
  console.log("📄 Created new data.json file");
}

console.log("📁 Saving to:", dataFile);

// 🔹 Helper function to load posts from data.json
function loadPosts() {
  try {
    const data = fs.readFileSync(dataFile, "utf8");
    return JSON.parse(data || "[]");
  } catch (err) {
    console.error("❌ Error reading data.json:", err);
    return [];
  }
}

// 🔹 Helper function to save posts to data.json
function savePosts(posts) {
  try {
    fs.writeFileSync(dataFile, JSON.stringify(posts, null, 2));
    console.log("✅ Data saved to data.json");
  } catch (err) {
    console.error("❌ Error saving file:", err);
  }
}

// 🟢 Get all posts
app.get("/api/posts", (req, res) => {
  const posts = loadPosts();
  res.json(posts);
});

// 🟢 Create new post
app.post("/api/posts", (req, res) => {
  const posts = loadPosts();
  const { title, content } = req.body;

  if (!title || !content) {
    return res.status(400).json({ message: "Title and content are required" });
  }

  const newPost = { id: uuid(), title, content, comments: [] };
  posts.push(newPost);
  savePosts(posts);
  res.json(newPost);
});

// 🟡 Update existing post
app.put("/api/posts/:id", (req, res) => {
  const posts = loadPosts();
  const { id } = req.params;
  const { title, content } = req.body;

  const post = posts.find((p) => p.id === id);
  if (!post) return res.status(404).json({ message: "Post not found" });

  post.title = title;
  post.content = content;
  savePosts(posts);
  res.json(post);
});

// 🔴 Delete post
app.delete("/api/posts/:id", (req, res) => {
  let posts = loadPosts();
  const { id } = req.params;
  const existing = posts.find((p) => p.id === id);
  if (!existing) return res.status(404).json({ message: "Post not found" });

  posts = posts.filter((p) => p.id !== id);
  savePosts(posts);
  res.json({ message: "Post deleted" });
});

// 💬 Add comment
app.post("/api/posts/:id/comments", (req, res) => {
  const posts = loadPosts();
  const { id } = req.params;
  const { text } = req.body;

  const post = posts.find((p) => p.id === id);
  if (!post) return res.status(404).json({ message: "Post not found" });
  if (!text) return res.status(400).json({ message: "Comment text is required" });

  const newComment = { id: uuid(), text };
  post.comments.push(newComment);
  savePosts(posts);
  res.json(newComment);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
