const API = 'http://localhost:5000/api'; // adjust if needed

// helpers
async function apiFetch(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts
  });
  const text = await res.text();
  try { return JSON.parse(text || '{}'); } catch { return text; }
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleString();
}

// render events
async function loadEvents() {
  const eventsList = document.getElementById('eventsList');
  const events = await apiFetch('/events');
  eventsList.innerHTML = events.map(ev => `
    <div class="event-card">
      <h3>${ev.title}</h3>
      <p>${ev.description || ''}</p>
      <p><strong>Date:</strong> ${formatDate(ev.date)}</p>
      <p><strong>Location:</strong> ${ev.location || 'TBA'}</p>
      <p><strong>Attendees:</strong> ${ev.attendees ? ev.attendees.length : 0}</p>
      <div class="event-actions">
        <button data-action="register" data-id="${ev.id}">Register</button>
        <button data-action="view" data-id="${ev.id}">View Attendees</button>
        <button class="danger" data-action="delete" data-id="${ev.id}">Delete</button>
      </div>
    </div>
  `).join('');
}

// create event form
document.getElementById('createEventForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  const body = {
    title: f.title.value,
    description: f.description.value,
    date: new Date(f.date.value).toISOString(),
    location: f.location.value,
    maxAttendees: f.maxAttendees.value ? Number(f.maxAttendees.value) : null
  };
  const created = await apiFetch('/events', { method: 'POST', body: JSON.stringify(body) });
  if (created && created.id) {
    alert('✅ Event created successfully!');
    f.reset();
    loadEvents();
  } else {
    alert('❌ Error creating event: ' + (created.error || 'unknown'));
  }
});

// delegate event buttons
document.getElementById('eventsList').addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.action;
  if (action === 'register') openRegisterPanel(id);
  if (action === 'view') openAttendeesPanel(id);
  if (action === 'delete') handleDeleteEvent(id);
});

// DELETE event logic
async function handleDeleteEvent(id) {
  if (!confirm('🗑️ Are you sure you want to delete this event?')) return;
  const res = await apiFetch(`/events/${id}`, { method: 'DELETE' });
  if (res && res.message) {
    alert('✅ ' + res.message);
    loadEvents();
  } else {
    alert('❌ Error deleting event');
  }
}

// panel helpers
const panel = document.getElementById('panel');
const panelContent = document.getElementById('panelContent');
document.getElementById('closePanel').addEventListener('click', () => { 
  panel.classList.add('hidden'); 
});

async function openRegisterPanel(eventId) {
  panel.classList.remove('hidden');
  panelContent.innerHTML = `<h3>Register for event</h3>
    <form id="registerForm">
      <input name="name" placeholder="Your name" required />
      <input name="email" type="email" placeholder="Your email" required />
      <button type="submit">Register</button>
    </form>
    <div id="regMsg"></div>
  `;
  document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = e.target.name.value.trim();
    const email = e.target.email.value.trim();
    const res = await apiFetch(`/events/${eventId}/register`, { 
      method: 'POST', 
      body: JSON.stringify({ name, email })
    });
    const msg = document.getElementById('regMsg');
    if (res && res.id) {
      msg.innerText = '🎉 Registered successfully!';
      loadEvents();
    } else {
      msg.innerText = '❌ Error: ' + (res.error || 'unknown');
    }
  });
}

async function openAttendeesPanel(eventId) {
  panel.classList.remove('hidden');
  panelContent.innerHTML = '<h3>Attendees</h3><div id="attList">Loading...</div>';
  const attendees = await apiFetch(`/events/${eventId}/attendees`);
  const list = document.getElementById('attList');
  if (!attendees || attendees.length === 0) {
    list.innerHTML = '<p>No attendees yet</p>';
  } else {
    list.innerHTML = '<ul>' + attendees.map(a => 
      `<li>${a.name} (${a.email})</li>`
    ).join('') + '</ul>';
  }
}

// initial load
loadEvents();
