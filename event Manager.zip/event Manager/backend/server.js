const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'data.json');

// 🧱 Helper functions
function readData() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ events: [] }, null, 2));
  }

  const data = JSON.parse(fs.readFileSync(DATA_FILE));

  // ✅ Auto-convert old "_id" fields to "id"
  if (data.events) {
    data.events = data.events.map(e => {
      if (e._id && !e.id) {
        e.id = e._id;
        delete e._id;
      }
      return e;
    });

    // Save back if conversion happened
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  }

  return data;
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// 🧩 CREATE EVENT
app.post('/api/events', (req, res) => {
  const db = readData();
  const { title, date, location, description } = req.body;

  if (!title || !date) {
    return res.status(400).json({ error: 'Title and date are required' });
  }

  const id = Math.random().toString(36).substring(2, 12);
  const newEvent = { id, title, date, location, description, attendees: [] };

  db.events.push(newEvent);
  writeData(db);
  res.status(201).json(newEvent);
});

// 🧩 LIST EVENTS
app.get('/api/events', (req, res) => {
  const db = readData();
  res.json(db.events);
});

// 🧩 UPDATE EVENT
app.put('/api/events/:id', (req, res) => {
  const db = readData();
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  Object.assign(event, req.body);
  writeData(db);
  res.json(event);
});

// 🧩 DELETE EVENT (fixed)
app.delete('/api/events/:id', (req, res) => {
  const db = readData();

  console.log('Delete request for:', req.params.id);
console.log('Current events:', db.events.map(e => e.id));


  const index = db.events.findIndex(e => e.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Event not found' });

  const deleted = db.events.splice(index, 1)[0];
  writeData(db);
  res.json({ message: 'Event deleted successfully', deleted });
});

// 🧩 REGISTER ATTENDEE
app.post('/api/events/:id/register', (req, res) => {
  const db = readData();
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  const { name, email } = req.body;
  if (!name || !email)
    return res.status(400).json({ error: 'Name and email required' });

  event.attendees.push({ id: Date.now().toString(), name, email });
  writeData(db);
  res.json({ message: 'Registration successful', event });
});

// 🧩 GET ATTENDEES
app.get('/api/events/:id/attendees', (req, res) => {
  const db = readData();
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  res.json(event.attendees);
});

// 🚀 START SERVER
app.listen(PORT, () => {
  console.log(`✅ Backend running at: http://localhost:${PORT}`);
});
